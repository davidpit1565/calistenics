package com.calisthenicsjourney.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
