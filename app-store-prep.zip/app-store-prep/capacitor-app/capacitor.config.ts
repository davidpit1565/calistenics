import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.calisthenicsjourney.app',
  appName: 'Calisthenics Journey',
  webDir: 'www'
};

export default config;
