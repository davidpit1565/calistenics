import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.massacalisthenics.app',
  appName: 'Massa Calisthenics',
  webDir: 'www'
};

export default config;
