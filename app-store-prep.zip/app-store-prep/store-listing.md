# Store Listing Copy — Massa Calisthenics / מאסה קליסטניקס

Ready to paste into App Store Connect and Google Play Console.

---

## 🇮🇱 Hebrew (he)

**App Name:** מאסה קליסטניקס
**Subtitle (App Store, 30 char max):** בונים גוף חזק, בלי מכון כושר
**Short description (Play Store, 80 char max):** קליסטניקס, תזונה ומעקב התקדמות — הכל במקום אחד

**Full description:**
מאסה קליסטניקס היא אפליקציית אימונים מלאה לבניית כוח וגמישות באמצעות משקל גוף בלבד — בלי צורך במכון כושר.

**מה כלול:**
• 5 רמות התקדמות מתחיל ועד מקצוען, עם 30+ תרגילים וסרטוני הדרכה
• ניתוח AI לביצוע תרגילים דרך המצלמה
• תוכנית תזונה אישית מבוססת משקל, גובה, גיל ורמת פעילות
• מעקב מים חכם עם התאמה לפי רמת פעילות
• מעקב מדדי גוף ותמונות התקדמות
• אתגר יומי ומצב מירוץ נגד השעון
• תזכורות אימון חכמות ומצב הפגה למניעת שחיקה
• עובד אופליין למעקב אימונים והתקדמות
• זמין באנגלית (עוד שפות בקרוב)

**Keywords (App Store, 100 char max, comma separated):**
קליסטניקס,אימון כוח,משקל גוף,מתח,שכיבות שמיכה,כושר,תזונה,ללא ציוד

**Category:** Health & Fitness

---

## 🇬🇧 English (en)

**App Name:** Massa Calisthenics
**Subtitle (App Store, 30 char max):** Build strength, no gym needed
**Short description (Play Store, 80 char max):** Calisthenics, nutrition & progress tracking — all in one place

**Full description:**
Massa Calisthenics is a complete bodyweight training app for building strength and flexibility — no gym required.

**What's included:**
• 5 progressive levels from beginner to pro, with 30+ exercises and instructional videos
• AI-powered form analysis via your camera
• Personal nutrition plan based on your weight, height, age, and activity level
• Smart water tracking that adjusts to your activity level
• Body metrics and progress photo tracking
• Daily challenges and race-against-the-clock mode
• Smart workout reminders and a deload mode to prevent burnout
• Works offline for logging workouts and tracking progress
• Available in English (more languages coming soon)

**Keywords (App Store, 100 char max, comma separated):**
calisthenics,bodyweight training,pull ups,push ups,fitness,strength,nutrition,no equipment

**Category:** Health & Fitness

---

## 🇳🇱 Dutch (nl)

**App Name:** Massa Calisthenics
**Subtitle:** Kracht opbouwen, zonder sportschool
**Short description:** Calisthenics, voeding en voortgang bijhouden — alles in één app

**Full description:**
Massa Calisthenics is een complete lichaamsgewicht-trainingsapp om kracht en flexibiliteit op te bouwen — zonder sportschool.

**Wat zit erin:**
• 5 progressieve niveaus van beginner tot pro, met 30+ oefeningen en instructievideo's
• AI-gestuurde vormanalyse via je camera
• Persoonlijk voedingsplan op basis van gewicht, lengte, leeftijd en activiteitsniveau
• Slimme waterinname-tracker die zich aanpast aan je activiteitsniveau
• Lichaamsmetingen en voortgangsfoto's bijhouden
• Dagelijkse uitdagingen en race-tegen-de-klok modus
• Slimme trainingsherinneringen en een deload-modus tegen overtraining
• Werkt offline voor het bijhouden van trainingen en voortgang
• Beschikbaar in het Engels (meer talen binnenkort)

**Keywords:**
calisthenics,lichaamsgewicht training,pull ups,push ups,fitness,kracht,voeding,zonder apparatuur

**Category:** Health & Fitness

---

## 🇪🇸 Spanish (es)

**App Name:** Massa Calisthenics
**Subtitle:** Fuerza sin necesidad de gimnasio
**Short description:** Calistenia, nutrición y seguimiento de progreso — todo en un solo lugar

**Full description:**
Massa Calisthenics es una app completa de entrenamiento con peso corporal para desarrollar fuerza y flexibilidad — sin necesidad de gimnasio.

**Qué incluye:**
• 5 niveles progresivos de principiante a profesional, con más de 30 ejercicios y videos instructivos
• Análisis de técnica con IA a través de tu cámara
• Plan nutricional personal basado en tu peso, altura, edad y nivel de actividad
• Seguimiento inteligente de hidratación que se ajusta a tu nivel de actividad
• Seguimiento de medidas corporales y fotos de progreso
• Desafíos diarios y modo carrera contra el reloj
• Recordatorios inteligentes de entrenamiento y modo de descarga para evitar el agotamiento
• Funciona sin conexión para registrar entrenamientos y progreso
• Disponible en inglés (más idiomas próximamente)

**Keywords:**
calistenia,entrenamiento peso corporal,dominadas,flexiones,fitness,fuerza,nutrición,sin equipo

**Category:** Health & Fitness

---

## Required Screenshots (per store)
- **Apple App Store:** iPhone 6.9" (1320×2868) and 6.5" — minimum 3, up to 10 per device size
- **Google Play:** at least 2 screenshots, 16:9 or 9:16, min 320px

## Age Rating
- Fitness/health content only, no violence, no user-generated content sharing → typically rated 4+ (Apple) / Everyone (Google), but confirm via each store's questionnaire since the nutrition/BMI-adjacent questions may trigger a "Medical/Treatment Information" flag on Apple's form — answer honestly, it should still clear at the lowest tier given no diagnosis is made.

## Data Safety / Privacy declarations (both stores now require this in the submission form)
Based on the actual architecture: **no data collected by the developer, no data shared with third parties, no data linked to identity.** All data stays on-device. This is a strong, simple answer — fill the forms accordingly rather than the vague defaults.
